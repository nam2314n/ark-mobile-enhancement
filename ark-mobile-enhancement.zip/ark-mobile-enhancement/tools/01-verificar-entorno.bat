@echo off
chcp 65001 >nul 2>&1
title ARK Mobile Toolkit - Verificar Entorno
color 0A

echo ╔══════════════════════════════════════════════════════════╗
echo ║     ARK MOBILE ENHANCEMENT TOOLKIT                      ║
echo ║     Paso 1: Verificar Entorno                           ║
echo ║                                                          ║
echo ║     Este script revisa si tienes todo lo necesario       ║
echo ║     instalado en tu PC antes de empezar a modificar.     ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

set "errores=0"

:: ---- Verificar Java ----
echo [1/4] Verificando Java...
java -version >nul 2>&1
if %errorlevel% equ 0 (
    echo     [OK] Java esta instalado
    for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do (
        echo     Version: %%~v
    )
) else (
    echo     [ERROR] Java NO esta instalado o no esta en PATH
    echo.
    echo     Como instalarlo:
    echo     1. Ve a: https://www.java.com/download/
    echo     2. Descarga e instala "Java Runtime Environment"
    echo     3. Reinicia tu PC si te lo pide
    echo     4. Vuelve a ejecutar este script
    set /a errores+=1
)
echo.

:: ---- Verificar 7-Zip ----
echo [2/4] Verificando 7-Zip...
where 7z >nul 2>&1
if %errorlevel% equ 0 (
    echo     [OK] 7-Zip esta instalado
) else (
    echo     [ADVERTENCIA] 7-Zip no encontrado en PATH
    echo.
    echo     No es obligatorio pero sera necesario para el OBB.
    echo     Descarga: https://www.7-zip.org/download.html
    echo     Instalalo y asegurate de marcar "Add to PATH"
    echo.
)
echo.

:: ---- Verificar Apktool ----
echo [3/4] Verificando Apktool...
if exist "apktool.jar" (
    echo     [OK] apktool.jar encontrado en la carpeta actual
) else (
    echo     [FALTA] apktool.jar NO encontrado
    echo.
    echo     Como obtenerlo:
    echo     1. Ve a: https://apktool.org/
    echo     2. Descarga "apktool_x.xx.jar"
    echo     3. Renombralo a "apktool.jar"
    echo     4. Copialo a esta carpeta: %cd%
    set /a errores+=1
)
echo.

:: ---- Verificar estructura de carpetas ----
echo [4/4] Verificando carpetas del proyecto...
if exist "..\..\1-original" (
    echo     [OK] Carpeta 1-original encontrada
    if exist "..\..\1-original\*.apk" (
        echo     [OK] APK encontrado en 1-original
    ) else (
        echo     [FALTA] No hay .apk en 1-original
        set /a errores+=1
    )
    if exist "..\..\1-original\*.obb" (
        echo     [OK] OBB encontrado en 1-original
    ) else (
        echo     [ADVERTENCIA] No hay .obb en 1-original
        echo         Lo necesitaras mas adelante para modificar graficos.
    )
) else (
    echo     [FALTA] No se encuentra la estructura de carpetas
    echo.
    echo     Debes tener esta estructura:
    echo       ArkMobile/
    echo       ├── 1-original/    ^← Aqui van el APK y OBB
    echo       ├── 2-workspace/
    echo       ├── 3-build/
    echo       └── ark-mobile-enhancement/  ^← Este repo (donde estamos ahora)
    set /a errores+=1
)
echo.

:: ---- Resumen ----
echo ╔══════════════════════════════════════════════════════════╗
echo ║                    RESUMEN                              ║
echo ╚══════════════════════════════════════════════════════════╝

if %errores% equ 0 (
    echo.
    echo     Todo esta listo! Puedes continuar con el Paso 2.
    echo     Ejecuta: 02-decompilar-apk.bat
    echo.
    color 0A
) else (
    echo.
    echo     Hay %errores% problema(s) que debes resolver primero.
    echo     Lee las instrucciones de arriba para cada error.
    echo.
    color 0C
)

pause
