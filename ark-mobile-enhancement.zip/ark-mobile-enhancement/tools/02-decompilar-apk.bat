@echo off
chcp 65001 >nul 2>&1
title ARK Mobile Toolkit - Decompilar APK
color 0B

echo ╔══════════════════════════════════════════════════════════╗
echo ║     ARK MOBILE ENHANCEMENT TOOLKIT                      ║
echo ║     Paso 2: Decompilar el APK                           ║
echo ║                                                          ║
echo ║     Esto desempaqueta el APK para que podamos ver y      ║
echo ║     modificar su contenido (codigo, recursos, etc.)     ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

:: ---- Verificar que apktool.jar existe ----
if not exist "apktool.jar" (
    echo [ERROR] No encuentro apktool.jar en esta carpeta.
    echo.
    echo Descargalo de: https://apktool.org/
    echo Renombralo a "apktool.jar" y ponlo junto a este .bat
    echo.
    pause
    exit /b 1
)

:: ---- Definir rutas ----
set "ORIGINAL_DIR=..\..\1-original"
set "WORKSPACE_DIR=..\..\2-workspace"
set "OUTPUT_DIR=%WORKSPACE_DIR%\apk-decompiled"

:: ---- Buscar el APK ----
echo Buscando el APK en %ORIGINAL_DIR%...
set "APK_FILE="
for %%f in ("%ORIGINAL_DIR%\*.apk") do (
    set "APK_FILE=%%f"
)

if "%APK_FILE%"=="" (
    echo [ERROR] No se encontro ningun archivo .apk
    echo Asegurate de que el APK este en la carpeta 1-original/
    echo.
    pause
    exit /b 1
)

echo [OK] APK encontrado: %APK_FILE%
echo.

:: ---- Crear carpeta de salida ----
if not exist "%OUTPUT_DIR%" (
    echo Creando carpeta de trabajo: %OUTPUT_DIR%
    mkdir "%OUTPUT_DIR%"
)
echo.

:: ---- Decompilar ----
echo ══════════════════════════════════════════════════════════
echo  DESCOMPILANDO... Esto puede tardar 2 a 5 minutos.
echo  No cierres esta ventana.
echo ══════════════════════════════════════════════════════════
echo.

java -jar apktool.jar d "%APK_FILE%" -o "%OUTPUT_DIR%" -f

echo.
if %errorlevel% equ 0 (
    echo ╔══════════════════════════════════════════════════════════╗
    echo ║     DESCOMPILACION COMPLETADA CON EXITO!               ║
    echo ╚══════════════════════════════════════════════════════════╝
    echo.
    echo     Los archivos descompilados estan en:
    echo     %OUTPUT_DIR%\
    echo.
    echo     Que encontraras ahi:
    echo     ├── AndroidManifest.xml   Configuracion de la app
    echo     ├── smali/                Codigo Java decompilado
    echo     ├── res/                  Iconos, imagenes, layouts
    echo     ├── lib/                  Librerias nativas (.so)
    echo     └── assets/               Recursos del juego
    echo.
    echo     Siguiente paso: Ejecuta 03-extraer-obb.bat
    echo.
    color 0A
) else (
    echo ╔══════════════════════════════════════════════════════════╗
    echo ║     ERROR EN LA DESCOMPILACION                         ║
    echo ╚══════════════════════════════════════════════════════════╝
    echo.
    echo     Revisa el error de arriba. Causas comunes:
    echo     - Java no esta instalado correctamente
    echo     - El APK esta corrupto
    echo     - No hay suficiente espacio en disco
    echo.
    color 0C
)

pause
