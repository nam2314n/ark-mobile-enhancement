@echo off
chcp 65001 >nul 2>&1
title ARK Mobile Toolkit - Extraer OBB
color 0E

echo ╔══════════════════════════════════════════════════════════╗
echo ║     ARK MOBILE ENHANCEMENT TOOLKIT                      ║
echo ║     Paso 3: Explorar el OBB                             ║
echo ║                                                          ║
echo ║     El OBB contiene los archivos .pak de Unreal Engine 4 ║
echo ║     (texturas, modelos, sonidos, mapas del juego).      ║
echo ║     Aqui solo vamos a LISTAR su contenido.              ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

:: ---- Definir rutas ----
set "ORIGINAL_DIR=..\..\1-original"
set "WORKSPACE_DIR=..\..\2-workspace"
set "OUTPUT_DIR=%WORKSPACE_DIR%\obb-extracted"

:: ---- Buscar el OBB ----
echo Buscando el OBB en %ORIGINAL_DIR%...
set "OBB_FILE="
for %%f in ("%ORIGINAL_DIR%\*.obb") do (
    set "OBB_FILE=%%f"
)

if "%OBB_FILE%"=="" (
    echo [ERROR] No se encontro ningun archivo .obb
    echo Asegurate de que el OBB este en la carpeta 1-original/
    echo.
    pause
    exit /b 1
)

echo [OK] OBB encontrado: %OBB_FILE%
echo.

:: ---- Verificar 7-Zip ----
where 7z >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] 7-Zip no esta instalado o no esta en PATH.
    echo.
    echo     Necesitamos 7-Zip para abrir el OBB.
    echo.
    echo     Como instalar:
    echo     1. Ve a: https://www.7-zip.org/download.html
    echo     2. Descarga el instalador de 64 bits
    echo     3. Instalalo marcando "Add 7-Zip to PATH"
    echo     4. Cierra esta ventana y abrela de nuevo
    echo.
    pause
    exit /b 1
)

echo [OK] 7-Zip disponible
echo.

:: ---- Crear carpeta de salida ----
if not exist "%OUTPUT_DIR%" (
    echo Creando carpeta: %OUTPUT_DIR%
    mkdir "%OUTPUT_DIR%"
)
echo.

:: ---- Listar contenido del OBB ----
echo ══════════════════════════════════════════════════════════
echo  LISTANDO CONTENIDO DEL OBB...
echo ══════════════════════════════════════════════════════════
echo.

7z l "%OBB_FILE%"

echo.
echo ══════════════════════════════════════════════════════════
echo  EXTRAYENDO ARCHIVOS .PAK...
echo  Esto puede tardar varios minutos (el OBB es grande).
echo ══════════════════════════════════════════════════════════
echo.

7z x "%OBB_FILE%" -o"%OUTPUT_DIR%" -y *.pak

echo.
if %errorlevel% equ 0 (
    echo ╔══════════════════════════════════════════════════════════╗
    echo ║     EXTRACCION COMPLETADA!                             ║
    echo ╚══════════════════════════════════════════════════════════╝
    echo.
    echo     Los archivos estan en: %OUTPUT_DIR%\
    echo.
    echo     Los archivos .pak contienen:
    echo     - Texturas (ASTC, formato de compresion mobile)
    echo     - Modelos 3D (mallas de personajes, dinosaurs)
    echo     - Materiales (definiciones de superficies)
    echo     - Audio (efectos de sonido, musica)
    echo     - Mapas (niveles del juego)
    echo.
    echo     NOTA: Para abrir los .pak individualmente necesitas
    echo     UnrealPak (viene con UE4) o UModel.
    echo.
) else (
    echo ╔══════════════════════════════════════════════════════════╗
    echo ║     ERROR EN LA EXTRACCION                             ║
    echo ╚══════════════════════════════════════════════════════════╝
    echo.
    echo     Causas comunes:
    echo     - El OBB esta corrupto o incompleto
    echo     - No hay suficiente espacio en disco
    echo     - 7-Zip tuvo un problema con el archivo
    echo.
)

pause
