# Herramientas Necesarias

Lista completa de herramientas que usaremos en el proyecto, con enlaces de descarga y explicacion de cada una.

---

## Herramientas Obligatorias (Las necesitas SI o SI)

### 1. Java Runtime Environment (JRE) 8+
- **Para que sirve**: Apktool y otras herramientas de Java necesitan Java para funcionar
- **Descarga**: https://www.java.com/download/
- **Version recomendada**: Java 8 o 11 (las mas compatibles con Apktool)
- **Como verificar**: Abre CMD y escribe `java -version`

### 2. Apktool
- **Para que sirve**: Decompila y recompila archivos APK de Android. Nos permite ver el codigo smali, modificar el AndroidManifest, cambiar recursos y volver a armar el APK
- **Descarga**: https://apktool.org/
- **Version recomendada**: La mas reciente (2.9.x o superior)
- **Como usar**: `java -jar apktool.jar d archivo.apk` para decompilar

### 3. 7-Zip
- **Para que sirve**: Abre archivos comprimidos, incluyendo los OBB que son basicamente ZIPs con extension diferente
- **Descarga**: https://www.7-zip.org/download.html
- **Version recomendada**: 64-bit para Windows
- **Como usar**: Click derecho > 7-Zip > Extraer aqui

---

## Herramientas Recomendadas (Te facilitaran la vida)

### 4. Notepad++ (o VS Code)
- **Para que sirve**: Editor de texto avanzado. Esencial para editar codigo smali, XML y archivos de configuracion. El Bloc de notas de Windows no sirve (daña los archivos con codificacion incorrecta)
- **Descarga**: https://notepad-plus-plus.org/ (recomendado para principiantes)
- **Alternativa**: https://code.visualstudio.com/ (mas potente pero mas complejo)
- **Importante**: En Notepad++, ve a Configuracion > Preferencias > Nueva documento > Codificacion = UTF-8

### 5. UModel (UE Viewer)
- **Para que sirve**: Abre archivos .pak y .uasset de Unreal Engine. Puedes ver texturas, modelos 3D, animaciones y extraerlos individualmente
- **Descarga**: https://www.gildor.org/en/projects/umodel
- **Nota**: Puede que necesites configurar la version de UE (4.5 para Ark Mobile)

### 6. Ghidra
- **Para que sirve**: Desensamblador y decompilador de codigo binario. Nos servira para analizar las librerias .so nativas del juego y encontrar funciones para modificar
- **Descarga**: https://ghidra-sre.org/
- **Nota**: Es una herramienta de la NSA, es gratuita pero avanzada. La usaremos en fases posteriores.

---

## Herramientas Opcionales (Para fases avanzadas)

### 7. Unreal Engine 4 (version 4.5 o compatible)
- **Para que sirve**: Para abrir y editar archivos .uasset, crear/modificar texturas y modelos, y usar UnrealPak
- **Descarga**: https://www.unrealengine.com/download (a traves de Epic Games Launcher)
- **Nota**: UE 4.5 es muy vieja, puede que necesites una version mas moderna y adaptar los archivos

### 8. Wireshark
- **Para que sirve**: Captura y analiza trafico de red. Lo necesitaremos para la Fase 6 (emulador de servidores) para entender el protocolo de comunicacion del juego
- **Descarga**: https://www.wireshark.org/
- **Nota**: Solo para la fase de servidores, mucho mas adelante

### 9. Uber Apk Signer
- **Para que sirve**: Firma el APK modificado para que Android lo acepte. Apktool incluye firma basica, pero esta herramienta es mas robusta
- **Descarga**: https://github.com/niclas-niclaus/uber-apk-signer/releases
- **Como usar**: `java -jar uber-apk-signer.jar -a mi-apk-modificado.apk`

---

## Resumen Rapido

| Herramienta | Necesaria? | Fase | Dificultad |
|-------------|-----------|------|-----------|
| Java | SI | Todas | Facil de instalar |
| Apktool | SI | 2 en adelante | Facil |
| 7-Zip | SI | 3 en adelante | Facil |
| Notepad++ | Recomendada | 2 en adelante | Facil |
| UModel | Recomendada | 4 en adelante | Media |
| Ghidra | Avanzada | 5+ | Dificil |
| Unreal Engine | Opcional | 4+ | Dificil |
| Wireshark | Opcional | 6 | Dificil |
| Uber Apk Signer | Opcional | Final | Facil |

---

## Orden de Instalacion

1. Java (primero, todo lo demas depende de esto)
2. 7-Zip
3. Apktool (descarga el .jar)
4. Notepad++ o VS Code
5. Reinicia tu PC
6. Ejecuta `01-verificar-entorno.bat` para confirmar que todo funciona
