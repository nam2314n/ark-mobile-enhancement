# Guia de Inicio - ARK Mobile Enhancement Toolkit

Esta guia te lleva paso a paso desde cero hasta tener el APK decompilado y listo para modificar. Sigue cada paso en orden.

---

## Requisitos Previos

Antes de empezar necesitas tener instalado:

1. **Windows 10 o 11** (ya lo tienes)
2. **Java 8 o superior** - Necesario para Apktool
3. **7-Zip** - Para abrir el OBB
4. **Git** - Ya lo tienes instalado
5. **Al menos 10GB libres** en tu disco (los archivos decompilados son grandes)

---

## Paso 0: Instalar Java y 7-Zip

### Java
1. Ve a https://www.java.com/download/
2. Descarga "Windows Offline (64-bit)"
3. Ejecuta el instalador
4. Reinicia tu PC si te lo pide
5. Para verificar: abre CMD y escribe `java -version`. Debe mostrarte la version.

### 7-Zip
1. Ve a https://www.7-zip.org/download.html
2. Descarga el `.exe` de 64-bit
3. Instalalo. IMPORTANTE: durante la instalacion, asegurate de marcar la opcion "Add 7-Zip to PATH" si aparece.
4. Para verificar: abre CMD y escribe `7z`. Debe mostrarte la ayuda de 7-Zip.

---

## Paso 1: Organizar archivos

Tu carpeta `ArkMobile` debe verse asi:

```
ArkMobile/
├── 1-original/
│   ├── ARK-Survival-Evolved-2.0.29.apk    ← Tu APK va aqui
│   └── main.com.studiowildcard....obb     ← Tu OBB va aqui
├── 2-workspace/                            ← Se llenara automaticamente
├── 3-build/                                ← El APK modificado final
└── ark-mobile-enhancement/                 ← Tu repo de GitHub (donde estan los scripts)
    ├── README.md
    ├── .gitignore
    ├── docs/
    ├── tools/
    │   ├── 01-verificar-entorno.bat
    │   ├── 02-decompilar-apk.bat
    │   ├── 03-extraer-obb.bat
    │   └── apktool.jar                     ← Descarga esto
    └── patches/
```

### Donde conseguir Apktool
1. Ve a https://apktool.org/
2. Descarga el `.jar` mas reciente (ej: `apktool_2.9.3.jar`)
3. Renombralo a **`apktool.jar`**
4. Ponlo DENTRO de la carpeta `tools/` junto a los `.bat`

---

## Paso 2: Verificar tu entorno

1. Abre la carpeta `ArkMobile/ark-mobile-enhancement/tools/`
2. Haz **doble click** en `01-verificar-entorno.bat`
3. El script revisara si Java, 7-Zip y Apktool estan listos
4. Si hay errores, leelos con calma y sigue las instrucciones
5. Repite este paso hasta que todo marque [OK]

**Nota**: Si la ventana se cierra muy rapido, abre CMD, navega a la carpeta y ejecuta el .bat desde ahi. Asi podras leer los errores.

Para hacerlo por CMD:
```
cd ArkMobile\ark-mobile-enhancement\tools
01-verificar-entorno.bat
```

---

## Paso 3: Decompilar el APK

1. Asegurate de que el APK este en `1-original/`
2. Haz **doble click** en `02-decompilar-apk.bat`
3. Espera 2-5 minutos (no cierres la ventana)
4. Cuando termine, revisa que se creo `2-workspace/apk-decompiled/`

### Que encontraras adentro:
| Carpeta | Que contiene | Para que sirve |
|---------|-------------|----------------|
| `AndroidManifest.xml` | Configuracion de la app | Quitar Google Play Services |
| `smali/` | Codigo Java decompilado | Modificar logica del juego |
| `smali*/` | Codigo deSmali de mas | Mas codigo decompilado |
| `res/` | Iconos, imagenes, layouts UI | Cambiar iconos, menus |
| `lib/` | Librerias .so (nativas) | Motor Unreal Engine |
| `assets/` | Recursos del juego | Configuraciones internas |

---

## Paso 4: Explorar el OBB

1. Asegurate de que el OBB este en `1-original/`
2. Haz **doble click** en `03-extraer-obb.bat`
3. El script listara y extraera los archivos .pak
4. Los .pak se guardaran en `2-workspace/obb-extracted/`

### Los archivos .pak son archivos comprimidos de Unreal Engine
Contienen: texturas, modelos 3D, sonidos, mapas. Para abrirlos individualmente necesitas:
- **UnrealPak** (viene con Unreal Engine 4)
- **UModel** (herramienta de terceros, mas facil)

---

## Paso 5: Subir a GitHub

Solo los archivos del repo van a GitHub. NUNCA subas:
- El APK
- El OBB
- Los archivos decompilados
- Ningun archivo .pak

Desde la carpeta `ark-mobile-enhancement/`:
```
git add .
git commit -m "Configuracion inicial del proyecto"
git push origin main
```

---

## Siguientes Fases (despues de completar estos pasos)

Una vez que tengas todo decompilado, las siguientes fases son:

- **Fase 3**: Fix de Google Play Services (eliminar la dependencia)
- **Fase 4**: Mejoras visuales (texturas, colores)
- **Fase 5**: Configuracion de rendimiento (FPS, memoria)
- **Fase 6**: Investigacion de servidores (avanzado)

Cada fase tendra sus propios scripts y guias.

---

## Problemas Comunes

### "La ventana del .bat se cierra rapido"
Abre CMD, navega a la carpeta y ejecuta el .bat desde ahi. El error permanecera visible.

### "Java no se reconoce"
Reinicia tu PC despues de instalar Java. Si persiste, busca "Variables de entorno" en Windows y agrega Java al PATH.

### "Apktool falla con error"
Asegurate de tener la version mas reciente de Apktool. Algunos APKs muy viejos pueden necesitar la version 2.4.x.

### "No hay suficiente espacio"
La decompilacion puede necesitar 5-10GB. Libera espacio en tu disco.

### "El OBB no se abre"
Verifica que el archivo .obb no este corrupto comparando su tamano con el original descargado.
