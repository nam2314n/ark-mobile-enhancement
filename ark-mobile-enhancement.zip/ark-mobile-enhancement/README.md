# ARK: Survival Evolved Mobile - Enhancement Toolkit

> Herramientas comunitarias para mejorar el rendimiento, visuales y estabilidad de ARK Mobile (v2.0.29) despues del abandono oficial del juego.

---

## Sobre el Proyecto

ARK: Survival Evolved Mobile fue portado por War Drum Studios (ahora Grove Street Games) usando Unreal Engine 4.5 personalizado. En 2024, Studio Wildcard abandono oficialmente el juego, cerrando servidores y retirandolo de la Play Store. Sin embargo, el modo jugador unico sigue funcional.

Este proyecto crea herramientas comunitarias para:
- **Rendimiento**: Optimizar texturas, reducir consumo de memoria, mejorar FPS
- **Estabilidad**: Eliminar dependencias de Google Play Services obsoletas
- **Visuales**: Mejorar texturas, iluminacion y efectos
- **Libertad**: Eventualmente crear infraestructura de servidores alternativa

## Estado del Proyecto

| Fase | Descripcion | Estado |
|------|-------------|--------|
| 1 | Configuracion del entorno | En progreso |
| 2 | Extraccion de activos | Pendiente |
| 3 | Fix Google Play Services | Pendiente |
| 4 | Mejoras visuales | Pendiente |
| 5 | Configuracion de rendimiento | Pendiente |
| 6 | Emulador de servidores | Investigacion |

## Requisitos

- Windows 10/11 (PC Gaming recomendida)
- Java 8+ instalado
- Al menos 10GB libres (para archivos decompilados)
- APK y OBB de ARK Mobile v2.0.29

## Estructura del Repositorio

```
ark-mobile-enhancement/
|-- README.md              <- Este archivo
|-- .gitignore             <- Protege contra subir archivos del juego
|-- docs/                  <- Guias y documentacion
|   |-- como-empezar.md    <- Guia paso a paso
|   |-- herramientas.md    <- Lista de herramientas necesarias
|   +-- fix-google-services.md <- Guia del fix de GMS
|-- tools/                 <- Scripts y herramientas
|   |-- 01-verificar-entorno.bat
|   |-- 02-decompilar-apk.bat
|   +-- 03-extraer-obb.bat
|-- patches/               <- Parches y configuraciones
|   |-- config/            <- Archivos de configuracion
|   +-- textures/          <- Texturas modificadas
```

## Estructura en tu PC (LOCAL - no en GitHub)

```
ArkMobile/
|-- 1-original/            <- APK + OBB originales (backup)
|-- 2-workspace/           <- Archivos de trabajo
|   |-- apk-decompiled/    <- APK decompilado por Apktool
|   +-- obb-extracted/     <- Activos extraidos del OBB
+-- 3-build/               <- APK modificado final
```

## Como Empezar

Lee la guia completa en [docs/como-empezar.md](docs/como-empezar.md)

## Herramientas Necesarias

Ve a [docs/herramientas.md](docs/herramientas.md) para la lista completa con enlaces de descarga.

## Aviso Legal

Este proyecto es con fines educativos y de preservacion comunitaria. No afiliado con Studio Wildcard, War Drum Studios, Grove Street Games o Nitrado. Los archivos del juego pertenecen a sus respectivos propietarios.

## Contribuciones

Contribuciones son bienvenidas. Lee los issues abiertos para ver tareas disponibles.

---

*Hecho con amor por la comunidad de ARK Mobile*
